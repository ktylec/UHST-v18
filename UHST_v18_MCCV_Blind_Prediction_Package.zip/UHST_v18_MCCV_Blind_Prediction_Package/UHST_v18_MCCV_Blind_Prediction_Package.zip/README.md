# UHST v18 – Vacuum Stress Framework

Author: Krzysztof Tylec

This repository contains the full reproducible pipeline used in the UHST v18 study.

## Contents

data/  
SPARC galaxy dataset and mass models.

results/  
Monte Carlo cross-validation outputs and figures.

scripts/  
Reproduction scripts.

paper/  
LaTeX manuscript draft.

documentation/  
Technical description of the UHST framework.

## Key result

Monte Carlo Blind Prediction (100 splits):

RMSE\_full  ≈ 23 km/s  
RMSE\_outer ≈ 21 km/s

Stable outer parameters suggest a universal vacuum stress response.

