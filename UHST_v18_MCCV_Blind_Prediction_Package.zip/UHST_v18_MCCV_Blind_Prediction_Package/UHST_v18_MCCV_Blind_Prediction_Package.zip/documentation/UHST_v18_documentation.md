

# UHST v18 Documentation

The Universal Halo Stress Theory models galaxy rotation curves using a vacuum stress response.

The model contains six global parameters controlling the transition between inner and outer regimes.

Validation is performed using Monte Carlo cross-validation on the SPARC galaxy sample.

See results/ for MCCV statistics and scripts/ for reproduction code.

