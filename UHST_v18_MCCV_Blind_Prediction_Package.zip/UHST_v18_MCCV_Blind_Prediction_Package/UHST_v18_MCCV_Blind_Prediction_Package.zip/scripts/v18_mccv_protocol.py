#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UHST v18 — Monte Carlo Blind Prediction Protocol (MCCV)
Pure global 6-parameter model, no E0, no dy.

This script reproduces the MCCV experiment used in UHST v18.
Expected input:
    out_v15/point_residuals_all.csv
Optional init:
    v16_best.json

Outputs:
    v18_MCCV_outputs/v18_mccv_per_iteration.csv
    v18_MCCV_outputs/v18_mccv_params_per_iteration.csv
    v18_MCCV_outputs/v18_mccv_summary.txt
"""

import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import spearmanr

# -----------------------------
# Paths / config
# -----------------------------
ROOT = Path(".")
CSV_PATH = ROOT / "out_v15" / "point_residuals_all.csv"
INIT_PATH = ROOT / "v16_best.json"
OUT_DIR = ROOT / "v18_MCCV_outputs"
OUT_DIR.mkdir(exist_ok=True)

# -----------------------------
# Protocol settings
# -----------------------------
N_SPLITS = 100
TEST_FRAC = 0.20
RANDOM_SEED = 20260306

OUTER_FRAC = 0.40
MIN_PTS_PER_GAL = 5

# v16-style train objective: outer-first, stable baseline
W_ETA = 0.50
W_SIG = 0.02

# optimizer
MAXITER = 220
XTOL = 1e-4
FTOL = 1e-4

# hard physical bounds
BOUNDS = [
    (-3.5,  1.0),   # y0_mid
    ( 0.10, 3.00),  # w_mid
    (-3.5,  1.0),   # y0_out
    ( 0.10, 3.00),  # w_out
    ( 0.20, 5.00),  # s_mid
    ( 0.20, 8.00),  # s_out
]

KPC_TO_M = 3.085677581491367e19


def clip_to_bounds(x):
    x = np.array(x, float)
    for i, (lo, hi) in enumerate(BOUNDS):
        x[i] = min(max(x[i], lo), hi)
    return x


def unpack(x):
    x = clip_to_bounds(x)
    y0_mid, w_mid, y0_out, w_out, s_mid, s_out = map(float, x)
    return dict(
        y0_mid=y0_mid, w_mid=w_mid,
        y0_out=y0_out, w_out=w_out,
        s_mid=s_mid, s_out=s_out,
    )


def sigmoid(z):
    z = np.clip(z, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))


def spearman_safe(a, b):
    rho, _ = spearmanr(a, b, nan_policy="omit")
    if rho is None or np.isnan(rho):
        return 0.0
    return float(rho)


def outer_mask(df, frac=0.40, min_pts=5):
    d = df.sort_values(["galaxy", "R_kpc"]).reset_index(drop=True)
    keep = np.zeros(len(d), dtype=bool)

    g = d["galaxy"].to_numpy()
    starts = np.flatnonzero(np.r_[True, g[1:] != g[:-1]])
    ends = np.r_[starts[1:], len(d)]

    for s, e in zip(starts, ends):
        n = e - s
        if n < min_pts:
            continue
        k = max(1, int(math.ceil(frac * n)))
        keep[e - k:e] = True

    return d.loc[keep].copy()


def build_vmodel(df, p):
    y = df["y"].to_numpy(float)
    R_m = df["R_kpc"].to_numpy(float) * KPC_TO_M

    a_bar = df["a_bar_mps2"].to_numpy(float)
    a_mid = df["a_vac_mid_mps2"].to_numpy(float)
    a_out = df["a_vac_out_mps2"].to_numpy(float)

    W_mid = sigmoid((y - p["y0_mid"]) / max(p["w_mid"], 1e-6))
    W_out = sigmoid((y - p["y0_out"]) / max(p["w_out"], 1e-6))

    a_vac = p["s_mid"] * W_mid * a_mid + p["s_out"] * W_out * a_out
    a_tot = np.clip(a_bar + np.maximum(a_vac, 0.0), 1e-40, None)

    V_kms = np.sqrt(a_tot * R_m) / 1000.0
    return V_kms, W_out


def metrics_block(df, p):
    Vmodel, W_out = build_vmodel(df, p)
    resid = df["Vobs_kms"].to_numpy(float) - Vmodel

    logR = np.log10(np.clip(df["R_kpc"].to_numpy(float), 1e-6, None))
    logA = np.log10(np.clip(df["a_bar_mps2"].to_numpy(float), 1e-30, None))

    a_out_eff = p["s_out"] * W_out * df["a_vac_out_mps2"].to_numpy(float)
    eta = a_out_eff / np.clip(df["a_bar_mps2"].to_numpy(float), 1e-30, None)
    log_eta = np.log10(np.clip(eta, 1e-30, None))

    rhoR = spearman_safe(resid, logR)
    rhoA = spearman_safe(resid, logA)
    rhoE = spearman_safe(resid, log_eta)

    sig = float(np.std(resid, ddof=1)) if len(resid) > 2 else float(np.std(resid))
    rmse = float(np.sqrt(np.mean(resid ** 2)))
    mae = float(np.mean(np.abs(resid)))
    mean_resid = float(np.mean(resid))

    tmp = df[["galaxy", "R_kpc"]].copy()
    tmp["resid"] = resid
    medR = tmp.groupby("galaxy")["R_kpc"].transform("median")
    inner = tmp[tmp["R_kpc"] <= medR]
    outer = tmp[tmp["R_kpc"] > medR]

    inner_rmse = float(np.sqrt(np.mean(inner["resid"].to_numpy() ** 2))) if len(inner) else float("nan")
    outer_rmse = float(np.sqrt(np.mean(outer["resid"].to_numpy() ** 2))) if len(outer) else float("nan")
    ratio = inner_rmse / outer_rmse if (np.isfinite(inner_rmse) and np.isfinite(outer_rmse) and outer_rmse > 0) else float("nan")

    return dict(
        rhoR=rhoR,
        rhoA=rhoA,
        rhoE=rhoE,
        sig=sig,
        rmse=rmse,
        mae=mae,
        mean_resid=mean_resid,
        inner_rmse=inner_rmse,
        outer_rmse=outer_rmse,
        ratio=ratio,
        n_points=len(df),
        n_galaxies=df["galaxy"].nunique(),
    )


def baseJ(m):
    return abs(m["rhoA"]) + abs(m["rhoR"]) + W_ETA * abs(m["rhoE"]) + W_SIG * m["sig"]


def main():
    assert CSV_PATH.exists(), f"Missing input CSV: {CSV_PATH}"

    df = pd.read_csv(CSV_PATH)
    required = {"galaxy", "R_kpc", "Vobs_kms", "y", "a_bar_mps2", "a_vac_mid_mps2", "a_vac_out_mps2"}
    missing = required - set(df.columns)
    assert not missing, f"Missing required columns: {missing}"

    galaxies = np.array(sorted(df["galaxy"].unique()))
    n_gal = len(galaxies)
    n_test = max(1, int(round(TEST_FRAC * n_gal)))

    print("[v18] Loaded points:", len(df), "| galaxies:", n_gal)
    print("[v18] MCCV splits:", N_SPLITS, "| test galaxies per split:", n_test)

    if INIT_PATH.exists():
        init_json = json.loads(INIT_PATH.read_text())
        x0_base = np.array([
            init_json["y0_mid"], init_json["w_mid"],
            init_json["y0_out"], init_json["w_out"],
            init_json["s_mid"],  init_json["s_out"],
        ], dtype=float)
        print("[v18] Init from v16_best.json")
    else:
        x0_base = np.array([-1.0, 0.8, -1.2, 0.5, 0.9, 3.7], dtype=float)
        print("[v18] Init from fallback defaults")

    x0_base = clip_to_bounds(x0_base)
    rng = np.random.default_rng(RANDOM_SEED)

    rows = []
    param_rows = []

    iter_csv = OUT_DIR / "v18_mccv_per_iteration.csv"
    param_csv = OUT_DIR / "v18_mccv_params_per_iteration.csv"

    t_all = time.time()

    for it in range(1, N_SPLITS + 1):
        t0 = time.time()

        test_gals = set(rng.choice(galaxies, size=n_test, replace=False))
        train_mask = ~df["galaxy"].isin(test_gals)
        test_mask = ~train_mask

        df_train_full = df.loc[train_mask].copy()
        df_test_full = df.loc[test_mask].copy()

        df_train_outer = outer_mask(df_train_full, frac=OUTER_FRAC, min_pts=MIN_PTS_PER_GAL)
        df_test_outer = outer_mask(df_test_full, frac=OUTER_FRAC, min_pts=MIN_PTS_PER_GAL)

        def cost(x):
            p = unpack(x)
            m_train_outer = metrics_block(df_train_outer, p)
            return float(baseJ(m_train_outer))

        jitter = rng.normal(0.0, [0.03, 0.05, 0.03, 0.05, 0.05, 0.10])
        x0 = clip_to_bounds(x0_base + jitter)

        res = minimize(
            cost,
            x0=x0,
            method="Powell",
            options=dict(maxiter=MAXITER, xtol=XTOL, ftol=FTOL, disp=False),
        )

        x_best = clip_to_bounds(res.x if np.all(np.isfinite(res.x)) else x0)
        p_best = unpack(x_best)

        m_train_full = metrics_block(df_train_full, p_best)
        m_train_outer = metrics_block(df_train_outer, p_best)
        m_test_full = metrics_block(df_test_full, p_best)
        m_test_outer = metrics_block(df_test_outer, p_best)

        rows.append({
            "iter": it,
            "success": bool(res.success),
            "nit": int(getattr(res, "nit", -1)),
            "fun_train_outer": float(cost(x_best)),
            "n_train_gal": df_train_full["galaxy"].nunique(),
            "n_test_gal": df_test_full["galaxy"].nunique(),
            "train_full_rmse": m_train_full["rmse"],
            "train_outer_rmse": m_train_outer["rmse"],
            "train_full_rhoR": m_train_full["rhoR"],
            "train_outer_rhoR": m_train_outer["rhoR"],
            "test_full_rmse": m_test_full["rmse"],
            "test_outer_rmse": m_test_outer["rmse"],
            "test_full_rhoR": m_test_full["rhoR"],
            "test_outer_rhoR": m_test_outer["rhoR"],
            "test_full_ratio": m_test_full["ratio"],
            "test_outer_ratio": m_test_outer["ratio"],
            "test_full_sig": m_test_full["sig"],
            "test_outer_sig": m_test_outer["sig"],
            "elapsed_s": time.time() - t0,
        })

        param_rows.append({
            "iter": it,
            **p_best,
        })

        pd.DataFrame(rows).to_csv(iter_csv, index=False)
        pd.DataFrame(param_rows).to_csv(param_csv, index=False)

        print(
            f"[v18] iter {it:03d}/{N_SPLITS} | "
            f"test_full_rmse={m_test_full['rmse']:.3f} | "
            f"test_outer_rmse={m_test_outer['rmse']:.3f} | "
            f"test_full_rhoR={m_test_full['rhoR']:+.3f} | "
            f"test_outer_rhoR={m_test_outer['rhoR']:+.3f} | "
            f"time={time.time()-t0:.1f}s"
        )

    res_df = pd.DataFrame(rows)
    par_df = pd.DataFrame(param_rows)

    summary_metrics = {
        "test_full_rmse": (res_df["test_full_rmse"].mean(), res_df["test_full_rmse"].std(ddof=1)),
        "test_outer_rmse": (res_df["test_outer_rmse"].mean(), res_df["test_outer_rmse"].std(ddof=1)),
        "test_full_rhoR": (res_df["test_full_rhoR"].mean(), res_df["test_full_rhoR"].std(ddof=1)),
        "test_outer_rhoR": (res_df["test_outer_rhoR"].mean(), res_df["test_outer_rhoR"].std(ddof=1)),
        "test_full_ratio": (res_df["test_full_ratio"].mean(), res_df["test_full_ratio"].std(ddof=1)),
        "test_outer_ratio": (res_df["test_outer_ratio"].mean(), res_df["test_outer_ratio"].std(ddof=1)),
    }

    summary_params = {
        c: (par_df[c].mean(), par_df[c].std(ddof=1))
        for c in ["y0_mid", "w_mid", "y0_out", "w_out", "s_mid", "s_out"]
    }

    summary_txt = OUT_DIR / "v18_mccv_summary.txt"
    with open(summary_txt, "w", encoding="utf-8") as f:
        f.write("UHST v18 MCCV SUMMARY\n")
        f.write("====================\n\n")
        f.write(f"N_SPLITS = {N_SPLITS}\n")
        f.write(f"TEST_FRAC = {TEST_FRAC}\n")
        f.write(f"OUTER_FRAC = {OUTER_FRAC}\n")
        f.write(f"Elapsed total = {time.time()-t_all:.2f} s\n\n")

        f.write("TEST METRICS (mean ± std)\n")
        for k, (mu, sd) in summary_metrics.items():
            f.write(f"{k}: {mu:.6f} ± {sd:.6f}\n")

        f.write("\nBEST-FIT PARAMETER DISPERSION (mean ± std)\n")
        for k, (mu, sd) in summary_params.items():
            f.write(f"{k}: {mu:.6f} ± {sd:.6f}\n")

    print("\n===================================================")
    print("v18 MCCV COMPLETE")
    print("===================================================")
    print(f"Elapsed total: {time.time()-t_all:.2f} s")

    print("\nTEST METRICS (mean ± std)")
    for k, (mu, sd) in summary_metrics.items():
        print(f"{k:>16s} : {mu:.6f} ± {sd:.6f}")

    print("\nPARAMETER DISPERSION (mean ± std)")
    for k, (mu, sd) in summary_params.items():
        print(f"{k:>8s} : {mu:.6f} ± {sd:.6f}")

    print("\nSaved files:")
    print(" -", iter_csv)
    print(" -", param_csv)
    print(" -", summary_txt)


if __name__ == "__main__":
    main()
