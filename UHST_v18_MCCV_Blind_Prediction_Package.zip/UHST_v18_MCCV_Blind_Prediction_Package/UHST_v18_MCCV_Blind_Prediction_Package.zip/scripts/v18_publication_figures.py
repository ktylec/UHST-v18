#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UHST v18 — Publication figures from MCCV outputs

Expected input:
    v18_MCCV_outputs/v18_mccv_per_iteration.csv
    v18_MCCV_outputs/v18_mccv_params_per_iteration.csv

Outputs:
    v18_MCCV_outputs/v18_hist_test_rmse.png
    v18_MCCV_outputs/v18_hist_test_rhoR.png
    v18_MCCV_outputs/v18_params_boxplot.png
    v18_MCCV_outputs/v18_params_violin.png
    v18_MCCV_outputs/v18_params_standardized_violin.png
    v18_MCCV_outputs/v18_publication_panel.png
    v18_MCCV_outputs/v18_publication_summary.csv
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(".")
OUT_DIR = ROOT / "v18_MCCV_outputs"

ITER_CSV = OUT_DIR / "v18_mccv_per_iteration.csv"
PARAM_CSV = OUT_DIR / "v18_mccv_params_per_iteration.csv"

assert ITER_CSV.exists(), f"Missing {ITER_CSV}"
assert PARAM_CSV.exists(), f"Missing {PARAM_CSV}"

res = pd.read_csv(ITER_CSV)
par = pd.read_csv(PARAM_CSV)

print("Loaded:")
print(" -", ITER_CSV, res.shape)
print(" -", PARAM_CSV, par.shape)

metrics_summary = {
    "test_full_rmse": (res["test_full_rmse"].mean(), res["test_full_rmse"].std(ddof=1)),
    "test_outer_rmse": (res["test_outer_rmse"].mean(), res["test_outer_rmse"].std(ddof=1)),
    "test_full_rhoR": (res["test_full_rhoR"].mean(), res["test_full_rhoR"].std(ddof=1)),
    "test_outer_rhoR": (res["test_outer_rhoR"].mean(), res["test_outer_rhoR"].std(ddof=1)),
}

param_cols = ["y0_mid", "w_mid", "s_mid", "y0_out", "w_out", "s_out"]
param_summary = {c: (par[c].mean(), par[c].std(ddof=1)) for c in param_cols}

# Figure 1
fig, axs = plt.subplots(1, 2, figsize=(13, 5.2))

x = res["test_full_rmse"].dropna().values
mu, sd = metrics_summary["test_full_rmse"]
axs[0].hist(x, bins=16, alpha=0.85)
axs[0].axvline(mu)
axs[0].axvline(mu - sd, linestyle="--")
axs[0].axvline(mu + sd, linestyle="--")
axs[0].set_title(f"Blind TEST RMSE (Full)\nmean = {mu:.2f}, std = {sd:.2f}")
axs[0].set_xlabel("RMSE_full [km/s]")
axs[0].set_ylabel("Count")
axs[0].grid(True, alpha=0.25)

x = res["test_outer_rmse"].dropna().values
mu, sd = metrics_summary["test_outer_rmse"]
axs[1].hist(x, bins=16, alpha=0.85)
axs[1].axvline(mu)
axs[1].axvline(mu - sd, linestyle="--")
axs[1].axvline(mu + sd, linestyle="--")
axs[1].set_title(f"Blind TEST RMSE (Outer)\nmean = {mu:.2f}, std = {sd:.2f}")
axs[1].set_xlabel("RMSE_outer [km/s]")
axs[1].set_ylabel("Count")
axs[1].grid(True, alpha=0.25)

plt.tight_layout()
hist_path = OUT_DIR / "v18_hist_test_rmse.png"
plt.savefig(hist_path, dpi=220, bbox_inches="tight")
plt.close(fig)

# Figure 2
fig, axs = plt.subplots(1, 2, figsize=(13, 5.2))

x = res["test_full_rhoR"].dropna().values
mu, sd = metrics_summary["test_full_rhoR"]
axs[0].hist(x, bins=16, alpha=0.85)
axs[0].axvline(0.0, linestyle=":")
axs[0].axvline(mu)
axs[0].axvline(mu - sd, linestyle="--")
axs[0].axvline(mu + sd, linestyle="--")
axs[0].set_title(f"Blind TEST Tilt $\\rho_R$ (Full)\nmean = {mu:.3f}, std = {sd:.3f}")
axs[0].set_xlabel(r"$\rho_R$ (full)")
axs[0].set_ylabel("Count")
axs[0].grid(True, alpha=0.25)

x = res["test_outer_rhoR"].dropna().values
mu, sd = metrics_summary["test_outer_rhoR"]
axs[1].hist(x, bins=16, alpha=0.85)
axs[1].axvline(0.0, linestyle=":")
axs[1].axvline(mu)
axs[1].axvline(mu - sd, linestyle="--")
axs[1].axvline(mu + sd, linestyle="--")
axs[1].set_title(f"Blind TEST Tilt $\\rho_R$ (Outer)\nmean = {mu:.3f}, std = {sd:.3f}")
axs[1].set_xlabel(r"$\rho_R$ (outer)")
axs[1].set_ylabel("Count")
axs[1].grid(True, alpha=0.25)

plt.tight_layout()
rho_path = OUT_DIR / "v18_hist_test_rhoR.png"
plt.savefig(rho_path, dpi=220, bbox_inches="tight")
plt.close(fig)

# Figure 3
labels = ["y0_mid", "w_mid", "s_mid", "y0_out", "w_out", "s_out"]
data = [par[c].dropna().values for c in labels]

fig, ax = plt.subplots(figsize=(11, 6))
ax.boxplot(data, labels=labels, showfliers=True)
ax.set_title("UHST v18 MCCV Parameter Stability (Box Plot)")
ax.set_ylabel("Parameter value")
ax.grid(True, axis="y", alpha=0.25)

for i, c in enumerate(labels, start=1):
    mu, sd = param_summary[c]
    ax.text(i, np.nanmax(par[c].values), f"{mu:.2f}\n±{sd:.2f}", ha="center", va="bottom", fontsize=9)

plt.tight_layout()
box_path = OUT_DIR / "v18_params_boxplot.png"
plt.savefig(box_path, dpi=220, bbox_inches="tight")
plt.close(fig)

# Figure 4
fig, ax = plt.subplots(figsize=(11, 6))
ax.violinplot(data, showmeans=True, showmedians=True, showextrema=True)
ax.set_xticks(range(1, len(labels) + 1))
ax.set_xticklabels(labels)
ax.set_title("UHST v18 MCCV Parameter Stability (Violin Plot)")
ax.set_ylabel("Parameter value")
ax.grid(True, axis="y", alpha=0.25)
ax.axvline(3.5, linestyle="--", alpha=0.7)
ymin, ymax = ax.get_ylim()
ax.text(2.0, ymax * 0.95, "MID regime", ha="center", va="top", fontsize=11)
ax.text(5.0, ymax * 0.95, "OUT regime", ha="center", va="top", fontsize=11)

plt.tight_layout()
violin_path = OUT_DIR / "v18_params_violin.png"
plt.savefig(violin_path, dpi=220, bbox_inches="tight")
plt.close(fig)

# Figure 5
zdata = []
for c in labels:
    x = par[c].astype(float).values
    mu = np.nanmean(x)
    sd = np.nanstd(x, ddof=1)
    z = np.zeros_like(x) if (sd <= 0 or np.isnan(sd)) else (x - mu) / sd
    zdata.append(z)

fig, ax = plt.subplots(figsize=(11, 6))
ax.violinplot(zdata, showmeans=True, showmedians=True, showextrema=True)
ax.set_xticks(range(1, len(labels) + 1))
ax.set_xticklabels(labels)
ax.axvline(3.5, linestyle="--", alpha=0.7)
ax.set_title("UHST v18 MCCV Parameter Spread (Standardized)")
ax.set_ylabel("Standardized value (z-score)")
ax.grid(True, axis="y", alpha=0.25)

plt.tight_layout()
zviolin_path = OUT_DIR / "v18_params_standardized_violin.png"
plt.savefig(zviolin_path, dpi=220, bbox_inches="tight")
plt.close(fig)

# Figure 6
fig = plt.figure(figsize=(13, 10))

ax1 = plt.subplot(2, 2, 1)
x = res["test_full_rmse"].dropna().values
mu, sd = metrics_summary["test_full_rmse"]
ax1.hist(x, bins=16, alpha=0.85)
ax1.axvline(mu)
ax1.axvline(mu - sd, linestyle="--")
ax1.axvline(mu + sd, linestyle="--")
ax1.set_title(f"TEST RMSE Full\n{mu:.2f} ± {sd:.2f}")
ax1.set_xlabel("km/s")
ax1.set_ylabel("Count")
ax1.grid(True, alpha=0.25)

ax2 = plt.subplot(2, 2, 2)
x = res["test_outer_rmse"].dropna().values
mu, sd = metrics_summary["test_outer_rmse"]
ax2.hist(x, bins=16, alpha=0.85)
ax2.axvline(mu)
ax2.axvline(mu - sd, linestyle="--")
ax2.axvline(mu + sd, linestyle="--")
ax2.set_title(f"TEST RMSE Outer\n{mu:.2f} ± {sd:.2f}")
ax2.set_xlabel("km/s")
ax2.set_ylabel("Count")
ax2.grid(True, alpha=0.25)

ax3 = plt.subplot(2, 2, 3)
mid_cols = ["y0_mid", "w_mid", "s_mid"]
mid_data = [par[c].dropna().values for c in mid_cols]
ax3.boxplot(mid_data, labels=mid_cols, showfliers=True)
ax3.set_title("MID parameters")
ax3.grid(True, axis="y", alpha=0.25)

ax4 = plt.subplot(2, 2, 4)
out_cols = ["y0_out", "w_out", "s_out"]
out_data = [par[c].dropna().values for c in out_cols]
ax4.boxplot(out_data, labels=out_cols, showfliers=True)
ax4.set_title("OUT parameters")
ax4.grid(True, axis="y", alpha=0.25)

plt.tight_layout()
panel_path = OUT_DIR / "v18_publication_panel.png"
plt.savefig(panel_path, dpi=240, bbox_inches="tight")
plt.close(fig)

summary_rows = []
for k, (mu, sd) in metrics_summary.items():
    summary_rows.append({"kind": "metric", "name": k, "mean": mu, "std": sd})
for k, (mu, sd) in param_summary.items():
    summary_rows.append({"kind": "parameter", "name": k, "mean": mu, "std": sd})

summary_df = pd.DataFrame(summary_rows)
summary_csv = OUT_DIR / "v18_publication_summary.csv"
summary_df.to_csv(summary_csv, index=False)

print("Saved:")
for p in [hist_path, rho_path, box_path, violin_path, zviolin_path, panel_path, summary_csv]:
    print(" -", p)
